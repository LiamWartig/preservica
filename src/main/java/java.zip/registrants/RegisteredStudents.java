package registrants;

import java.util.Collection;
import java.util.HashSet;

import service.Utils;

public class RegisteredStudents {
private static Collection<Student> registeredStudents = new HashSet<Student>();

Utils utils = new Utils();

public int registerStudent(final Student student) {

  final int studentId = utils.newStudentId();
  student.setStudentId(studentId);
  
registeredStudents.add(student);
return studentId;

}

public static Collection<Student> getRegisteredStudents(){
  return RegisteredStudents.registeredStudents;
}

}
