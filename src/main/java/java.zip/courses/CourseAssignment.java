package courses;

public class CourseAssignment {
  protected int studentId;
  protected int courseId;
  
  public CourseAssignment(final int courseIdIn, final int studentIdIn) {
    this.courseId=courseIdIn;
    this.studentId=studentIdIn;
  }

  public void setCourseId(final int courseIdIn) {
    this.courseId=courseIdIn;
  }
  public int getCourseId() {
    return this.courseId;
  }

  public void setStudentId(final int studentIdIn) {
this.studentId = studentIdIn;    
  }

  public int getStudentId() {
    return this.studentId;
  }


}
